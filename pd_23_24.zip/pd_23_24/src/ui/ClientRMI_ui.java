package ui;

public class ClientRMI_ui {
}
