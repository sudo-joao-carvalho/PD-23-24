package pt.isec.pd.meta2.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exemplo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
